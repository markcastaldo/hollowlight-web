Hollowlight - every sprite the current version of the game draws (873 images; the version is on the page).
Folders match the game's res://assets/<folder>/. Pixel art: scale with nearest-neighbour only.
Upload a redraw on hollowlightgame.com/spritesheet under the same file name.
